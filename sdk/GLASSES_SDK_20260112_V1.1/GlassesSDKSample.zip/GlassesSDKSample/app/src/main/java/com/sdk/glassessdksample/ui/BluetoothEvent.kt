package com.sdk.glassessdksample.ui

/**
 * @author hzy ,
 * @date  2021/1/15
 * <p>
 * "程序应该是写给其他人读的,
 * 让机器来运行它只是一个附带功能"
 **/
open class BluetoothEvent(val connect:Boolean)